<?php
/**
 * Front page — compact search-first hero + tag filter + latest galleries.
 *
 * Set Settings → Reading → "Your homepage displays" to a static page to use
 * this; or it renders on the site root automatically when posts page is root.
 *
 * @package Hygpo
 */

get_header();
?>

<main>

	<section class="hero">
		<span class="hero-pill">
			<span class="d" aria-hidden="true"></span>
			<?php esc_html_e( 'Universal prompt gallery', 'hygpo' ); ?>
		</span>
		<h1><?php esc_html_e( 'Browse images. Reveal the prompt.', 'hygpo' ); ?></h1>

		<?php
		// If the front page is a static Page that contains [mwf_search] or a tag
		// filter shortcode, render its content here. Otherwise show the search box.
		$front_id = get_option( 'page_on_front' );
		if ( $front_id && has_shortcode( get_post_field( 'post_content', $front_id ), 'mwf_search' ) ) {
			echo '<div class="mwf-search">';
			echo apply_filters( 'the_content', get_post_field( 'post_content', $front_id ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '</div>';
		} else {
			echo '<div class="mwf-search">';
			echo hygpo_search(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '</div>';
			echo '<p class="hero-hint">' . esc_html__( 'Search a mood, a subject, or a style — results are images only.', 'hygpo' ) . '</p>';
		}
		?>
	</section>

	<?php
	// Latest galleries (standard post loop, featured-image covers).
	$latest = new WP_Query( array(
		'post_type'           => 'post',
		'posts_per_page'      => 12,
		'ignore_sticky_posts' => 1,
	) );
	if ( $latest->have_posts() ) :
	?>
	<section class="section">
		<div class="section-head">
			<h2><?php esc_html_e( 'Latest galleries', 'hygpo' ); ?></h2>
			<a href="<?php echo esc_url( get_post_type_archive_link( 'post' ) ? get_post_type_archive_link( 'post' ) : home_url( '/blog/' ) ); ?>">
				<?php esc_html_e( 'View all →', 'hygpo' ); ?>
			</a>
		</div>
		<div class="masonry">
			<?php while ( $latest->have_posts() ) : $latest->the_post(); ?>
				<a class="card" href="<?php the_permalink(); ?>">
					<div class="thumb">
						<?php
						if ( has_post_thumbnail() ) {
							the_post_thumbnail( 'hygpo-card', array( 'loading' => 'lazy', 'alt' => esc_attr( get_the_title() ) ) );
						} else {
							echo '<div class="cover placeholder" style="aspect-ratio:3/4;" aria-hidden="true"></div>';
						}
						?>
					</div>
					<div class="title"><?php the_title(); ?></div>
				</a>
			<?php endwhile; ?>
		</div>
	</section>
	<?php
	endif;
	wp_reset_postdata();
	?>

</main>

<?php
get_footer();
